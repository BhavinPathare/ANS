<?php

//require_once 'db/db_config.php';



$lat=$_GET["lat"];
$long=$_GET["long"];
$licence=$_GET['licence'];
$vehicleowner=$_GET['vehicleowner'];
$carmodel=$_GET['carmodel'];

//echo "accident data uploaded successfully!";
//echo "<br>";
echo $n." ".$l;


$host = "ansdbserver.cxvctsaaynbc.ap-south-1.rds.amazonaws.com"; // host of MySql server
$user = "ajay443617"; // MySQL username
$pwd = "ajaybhavinans"; //MySQL password
$db = "ans";

$con = mysqli_connect($host, $user, $pwd, $db);
if(mysqli_connect_errno($con))
{
	die("Failed to connect to MySQL: ".mysqli_connect_error());
}
$sqlinsert = "INSERT into location (lat,lng,licence,vehicleowner,carmodel) values ('$lat','$long','$licence','$vehicleowner','$carmodel')";
if(mysqli_query($con,$sqlinsert))
{
	echo "success";
}
else
{
	echo "Failed";
}
mysqli_close($conn);
?>
