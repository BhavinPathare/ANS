<?php
function Connect_DB() {
    $db_host="ansdbserver.cxvctsaaynbc.ap-south-1.rds.amazonaws.com";
    $db_user="ajay443617";
    $db_password="ajaybhavinans";
    $db_name="ans";
    if($db_link=mysqli_connect($db_host,$db_user,$db_password,$db_name)) {
        return $db_link;
    }
    else {
        die("Connection Error");
    }
}
?>
