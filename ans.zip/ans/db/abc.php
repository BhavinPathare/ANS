<?php
echo $url= 'http://'.$_SERVER['HTTP_HOST'];

echo md5("a");
?>