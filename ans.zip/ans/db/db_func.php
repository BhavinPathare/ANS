<?php

require_once 'db_config.php';

function ValidateUser($mail,$pass)
{
    $query="SELECT `id`,`active_status` FROM `users` WHERE `email` = '$mail'";
    
    $db_link=Connect_DB();
    $status=2;
    if($query_run=mysqli_query($db_link,$query))
    {
        if(mysqli_num_rows($query_run)==0)
        {
            //No Records Found For The Current User Found
            echo "UNKNOWN USER";
        }
        else if(mysqli_num_rows($query_run)==1)
        {
            //Record Found With The Email address now fetch the primary key for that
            $row=mysqli_fetch_assoc($query_run);
            $password=getValue($row['id'],'password',$db_link);
            if($password==md5($pass))
            {
                //User has Been Successfully Validated
                $status=getValue($row['id'],'active_status',$db_link);
            }
            else
            {
                //Invalid Password
                echo "<script>document.getElementById('err_pwd').innerHTML='Invalid Password'</script>";
            }
        }
        else
        {
            //This condition will arise when the uniqueness of the email gets violated
            //Write the appriate error in the log file so that the admin can check and report for that, though this case is never goin to occur as the database is designed in that way only
        }
    }
    else{
    	$status = mysqli_error($ans);
    }
    mysqli_close($db_link);
    return $status;
}
function getValue($key,$value,$db_link)
{
    $query="SELECT `$value` FROM `users` WHERE `id` = $key";
    if($query_run=mysqli_query($db_link,$query))
    {
        $row=mysqli_fetch_assoc($query_run);
        return $row[$value];
    }
}

function insertValues($email,$add,$city,$state,$pin,$uname,$pass,$mob,$userlat,$userlong)
{
    $pass=md5($pass);
    $status=1;
    $time=date("Y-m-d H:i:s");
    $time=md5($time);

    $query="INSERT INTO `ans`.`users` (`id`, `email`, `address`, `city`, `state`, `pincode`, `username`, `password`, `mobile_no`,`auth_key`,'userlat','userlong') VALUES (NULL, '$email', '$add', '$city', '$state', '$pin', '$uname', '$pass', '$mob','$time','$userlat','$userlong')";
    
    $db_link=Connect_DB();
    
    $add=mysqli_real_escape_string($db_link,$add);
    
    if($query_run=mysqli_query($db_link,$query))
    {
        //Values Inserted Successfully send him/her an acknowledgement mail to activate his/her account
        $status=sendActivationMail($email,$time); //When Sending The Main For The First Time
    }
    else
    {
        $status=mysqli_error($db_link);
        //Recored An Error Log Here, and Inform The Admin about this issue
    }
    mysqli_close($db_link);
    return $status;
}


function valueExists($value,$type)
{
    $db_link=Connect_DB();
    $query="SELECT `id` FROM `users` WHERE $type = '$value'";
    if($query_run=mysqli_query($db_link,$query))
    {
        if(mysqli_num_rows($query_run)==0)
        {
            return false;
        }
        else
        {
            return true;
        }
        
    mysqli_close($db_link);
    }
}


function sendActivationMail($email,$key)
{
    $url= 'http://'.$_SERVER['HTTP_HOST'];
    $sub="Regarding Your $url Account Activation";
    $adres="$url/utilities/userActivation.php?authkey=".md5($email).$key.md5(strrev($email))."&email=".$email;
    $msg="To Activate Your Your Account Please Click On The Following Link : 
    
    
    $adres
    
    
    If You Have Any Problem Copy The Link Into Your Browser's Address Bar";
    
    if(mail($email,$sub,$msg))
    {
        return 1;
    }
                                                                     
}

function sanitize($value)
{
    $db_link=Connect_DB();
    $value=mysqli_real_escape_string($db_link,$value);
    mysqli_close($db_link);
    return $value;
}
function RetrieveValue($type,$value,$retValue)
{
    $db_link=Connect_DB();
    $query="SELECT `$retValue` FROM `users` WHERE $type = '$value'";
    if($query_run=mysqli_query($db_link,$query))
    {
        if(mysqli_num_rows($query_run)==1)
        {
            $row=mysqli_fetch_assoc($query_run);
            $retValue=$row[$retValue];
        }
        else
        {
            $retValue=0;
        }
    }
    mysqli_close($db_link);
    return $retValue;
}


?>