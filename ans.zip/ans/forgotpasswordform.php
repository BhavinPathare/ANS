<?php
if(!isset($_POST['submit'])){
if(isset($_GET['authkey']) && isset($_GET['email']))
{
require_once 'db/db_func.php';

$authkey=$_GET['authkey'];

$authkey=substr($authkey,0,32);

$db_link=Connect_DB();

$query="SELECT `id`,`email`,`status` FROM `resetpassword` WHERE `key` = '$authkey'";

if($query_run=mysqli_query($db_link,$query))
{
	if(mysqli_num_rows($query_run)!=0)
	{
	$row=mysqli_fetch_assoc($query_run);
	session_start();
        $_SESSION['email']=$row['email'];
        }
        else{
	header('location:index.php');
	}
	
    /*if(mysqli_num_rows($query_run)!=0)
    {echo "1";
        while($row=mysqli_fetch_assoc($query_run))
        {echo "2";
            if($row['status']==0)
            {echo "3";
                session_start();
                $_SESSION['email']=$row['email'];
                break;
            }
        }
        if(!isset($_SESSION['email']))
        {
            $url='http://'.$_SERVER['HTTP_HOST'];
            echo "<script>window.location='$url'</script>";
        }
        /*else
        {    
        require_once './updatePassword.php';
        }
    }
    else
    {
        $url='http://'.$_SERVER['HTTP_HOST'];
        echo "<script>window.location='$url'</script>";
    }*/
}

mysqli_close($db_link);
}
else
{die ("123");
	//header('location:index.php');
    /*$url='http://'.$_SERVER['HTTP_HOST'];
    echo "<script>window.location='$url'</script>";*/
}
}



if(isset($_POST['submit']))
{	require_once 'db/db_func.php';
$db_link=Connect_DB();
    $pass=$_POST['Password'];
    $cpass=$_POST['cPassword'];
    if($pass!=$cpass)
    {
    	echo "<script>document.getElementById('err').innerHTML='Passwords Do Not Match'</script>";
    }
    else if(empty($pass))
    {
    	echo "<script>document.getElementById('err').innerHTML='Password Can Not Be Empty'</script>";
    }
    else{
    session_start();
    $pass=md5($pass);
    $email=$_SESSION['email'];
    //echo "<script>alert('".$email."'); </script>";
    //$query="UPDATE `ans`.`users` SET `password` = '$pass' WHERE `users`.`email` = '$email'";
    $query = "UPDATE users SET password='$pass' WHERE email='$email'";
    if($query_run=mysqli_query($db_link,$query))
    {//die("good");
        //Password Updated Successfully
        //$query="UPDATE `ans`.`resetpassword` SET `status` = 1 WHERE `resetpassword`.`email` = '$email'";
        $query = "UPDATE  resetpassword SET status=1 WHERE email='$email' ";
        if($query_run=mysqli_query($db_link,$query))
        {
            //Both The Values Successfully Updated
            $_SESSION['st']=1;
            //echo "<script>window.location='recoverysuccess.php'</script>";
            header('location:recoverysuccess.php');
        }
        else{
        	echo mysqli_error($db_link);
        }
    }
    else{
    	//die ("122");
    	echo mysqli_error($db_link);
    	die();
    }
    }
}
?>

<!doctype html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Forgot Password</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="images/android-desktop.png">

    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <link rel="shortcut icon" href="images/favicon.png">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
    <link rel="stylesheet" href="style/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    #navlinkfont{
      color: black;
      font-size: 16px;
    }

    </style>
    
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-layout--fixed-header mdl-js-layout mdl-color--grey-100">

      <header class="demo-header mdl-layout__header mdl-layout__header--scroll mdl-color--grey-100 mdl-color-text--grey-800">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Accident Notification System</span>
          <div class="mdl-layout-spacer"></div>
          <nav class="mdl-navigation mdl-layout--large-screen-only myactext">
        <a class="mdl-navigation__link" id="navlinkfont" href="./index.php">Home</a>
        <a class="mdl-navigation__link" id="navlinkfont" href="utilities/help.php">Help</a>
        <a class="mdl-navigation__link" id="navlinkfont" href="utilities/contactus.php">Contact Us</a>
        <a class="mdl-navigation__link" id="navlinkfont"  href="utilities/aboutus.php">About Us</a>
      </nav>
          <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
            <label class="mdl-button mdl-js-button mdl-button--icon" for="search">
              <i class="material-icons">search</i>
            </label>
            <div class="mdl-textfield__expandable-holder">
              <input class="mdl-textfield__input" type="text" id="search">
            </div>
          </div>
        </div>
      </header>

      <div class="demo-ribbon"></div>
      <main class="demo-main mdl-layout__content">
        <div class="demo-container mdl-grid">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
          <center><h3>Please fill out the details below</h3></center>
            <form action="forgotpasswordform.php" align="center" name="f1" id="f1" method="post">
            
                
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="password" name="Password" required id="Password">
                    <label class="mdl-textfield__label" for="sample3">Enter New Password</label>
                </div><br><br>

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="password" required name="cPassword" id="cPassword">
                    <label class="mdl-textfield__label" for="sample3">Confirm Your Password</label>
					<small style="color:indianred" id='err'></small>
                </div><br><br>
                

                <br>
                <div class="myactext2">
                <!-- Accent-colored raised button -->
                  <!--<button class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent " >
                      Submit
                  </button>-->
				  
		<a href="./forgotpassword.php"><input type="button" name='submit' value="Back" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent"/></a>
	&nbsp;&nbsp;&nbsp;&nbsp;		  
				  
				  <input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent" value="Reset Password" name='submit'/>
                  </div>
            </form><br>
         </div>
        </div>
        
        <footer class="demo-footer mdl-mini-footer">
          <div class="mdl-mini-footer--left-section">
            <ul class="mdl-mini-footer--link-list">
              <li><a href="#">Credits</a></li>
              <li><a href="#">Privacy and Terms</a></li>
              <li><a href="#">User Agreement</a></li>
            </ul>
          </div>
        </footer>
      </main>
    </div>
	
    
    <script src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  </body>
</html>
