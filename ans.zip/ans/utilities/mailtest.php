<?php
$headers="MIME-Version: 1.0\r\n";$headers.="Content-Type: text/html";charset=ISO-8859-1\r\n";
mail('bhavinrp77@gmail.com','test','asd',$headers);
?>