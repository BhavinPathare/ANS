<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" type="text/css" href="https://code.getmdl.io/1.2.1/material.indigo-pink.min.css">
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
  

<?php 
include("./drawer.php"); 
?>
  
  <main class="mdl-layout__content">
    <div class="page-content">
    <div class="mdl-grid-myac">
      <!-- Simple Text -->
		<form align="center" class="myactext" method='POST' action="pwdchangesuccess.php">
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input class="mdl-textfield__input" type="password" id="sample3" name="oldpwd" required>
                    <label class="mdl-textfield__label" for="sample3">Enter Old Password</label>
                </div><br><br>

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input class="mdl-textfield__input" type="Password" id="sample3" name="newpwd" required>
                    <label class="mdl-textfield__label" for="sample3">Enter New Password</label>
                </div><br><br>
        
              <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input class="mdl-textfield__input" type="Password" id="sample3" name="cnewpwd" required>
                    <label class="mdl-textfield__label" for="sample3">Confirm New Password</label>
              </div><br><br>
              <button type="button" class="mdl-button show-modal mdl-button mdl-js-button mdl-button--raised mdl-button--colored">OK</button>
  
          <dialog class="mdl-dialog">
              <div class="mdl-dialog__content">
                <p>
                  Are you sure?
                </p>
              </div>
            <div class="mdl-dialog__actions mdl-dialog__actions--full-width">
                  <input type="submit" name='submit'class="mdl-button "  style="color: #5f08d1;text-decoration:none" value="Yes">
                  <button type="button" class="mdl-button close">No</button>
            </div>
          </dialog>

          <!-- script for option popup -->
          <script>
            var dialog = document.querySelector('dialog');
            var showModalButton = document.querySelector('.show-modal');
            if (! dialog.showModal) {
              dialogPolyfill.registerDialog(dialog);
            }
            showModalButton.addEventListener('click', function() {
              dialog.showModal();
            });
            dialog.querySelector('.close').addEventListener('click', function() {
              dialog.close();
            });
          </script>
     </form>
	  </div>
	</div>
  </main>
</div>
</body>
</html>
