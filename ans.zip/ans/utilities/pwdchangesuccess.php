<?php
require_once('../db/db_config.php');
session_start();
$msg = "";
$url="http://".$_SERVER['HTTP_HOST'];
if(!isset($_SESSION['user']))
{
	session_destroy();
	header('Location:'.$url);
}
$email=$_SESSION['user'];
//echo "Old Password: ".$_POST['oldpwd']." New Password: ".$_POST['newpwd']." Confirm Password: ".$_POST['cnewpwd'];
if(!isset($_POST['oldpwd']) || !isset($_POST['newpwd']) || !isset($_POST['cnewpwd'])){
	//When Someone Tries To Open The Page Forcibly.
	die("Access Denied..!!");
}
else{
	$oldpwd=$_POST['oldpwd'];
	$newpwd = $_POST['newpwd'];
	$cnewpwd = $_POST['cnewpwd'];
	if($newpwd != $cnewpwd) {
		$msg = "Passwords Don't Match";
	}
	else if($oldpwd == $newpwd){
		$msg = "Old Password And New Passwords Can't Be Same";
	}
	else{
		$row = "";
		$oldpwd = md5($oldpwd);
		$sql = "SELECT `password` FROM `users` WHERE `email` = '$email'";
		$db = Connect_DB();
		if($query=mysqli_query($db,$sql)){
			$row = mysqli_fetch_assoc($query);
		}
		if($oldpwd != $row['password']){
			$msg = "Old Password Incorrect..!!";
		}
		else{
			$cnewpwd = md5($newpwd);
			$sql = "UPDATE `users` SET `password` = '$cnewpwd' WHERE `email` = '$email'";
			if($query=mysqli_query($db,$sql)) {
				$msg = "Password Updated Successfully";
			}
		}
		mysqli_close($db);
	}
}
?>
<!DOCTYPE html>

<html>
<head>
  <title>Change Password</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

  <script type="text/javascript">
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>

<script type="text/javascript">
	function goToHome()
	{
		window.location='<?php
		echo $url;
		?>';
	}
</script>
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->

<?php
include("./drawer.php");
?>

  <!-- confirmation card -->
   <main class="mdl-layout__content">
    <div id="myModal"class="page-content">
			<div class="modal-header">
	      <h4 class="modal-title" style="padding-left:20px">Forgot your password</h4>
		  </div>
    	<div class="mdl-grid-myac ">
        <div class="demo-container mdl-grid ">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div  id="confirmation" class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
	          <center>
							<h4>
								<?php
									echo $msg;
								?>
							</h4>
							<div>
								<button type="button" onclick="goToHome()" class="btn btn-default" data-dismiss="modal">Close</button>
	            </div>
						</center>
          </div>
        </div>
	  </div>
	</div>
  </main>
</body>
</html>
