<!DOCTYPE html>
<html>
<head>
  <title>My Account</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
  
<?php
include("drawer.php"); 
?>
  
  <main class="mdl-layout__content">
    <div class="page-content">
    <div class="mdl-grid-myac">
      <!-- Hospitals Table -->
      
		<form class="cardalign myactext">
    <label class="myactext1" for="sample1">Ambulance Service Around You</label>
    <br><br><br>
    
          <table class="mdl-data-table mdl-js-data-table  mdl-shadow--3dp ">
          <thead>
                <tr>
                  <th class="mdl-data-table__cell--non-numeric">Name</th>
                  <th>Distance</th>
                  <th>Contact</th>
                  <th></th>
                </tr>
          </thead>
          <tbody>
                  <tr>
                    <td class="mdl-data-table__cell--non-numeric">H Care</td>
                    <td>0.5 KM</td>
                    <td>+7421655</td>
                    <td><i class="material-icons">call</i></td>
                  </tr>
                  <tr>
                    <td class="mdl-data-table__cell--non-numeric">H Care</td>
                    <td>1 KM</td>
                    <td>+5216565</td>
                    <td><i class="material-icons"><a href="http://www.twillio.com">call</a></i></td>
                  </tr>
                  <tr>
                    <td class="mdl-data-table__cell--non-numeric">H Care</td>
                    <td>2.5 KM</td>
                    <td>+5456565</td>
                    <td><i class="material-icons">call</i></td>
                  </tr>
          </tbody>
        </table>  
    </form>
  </div>
	</div>
  </main>
</div>
</body>
</html>
