<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
		        <label class="mdl-button mdl-js-button mdl-button--icon"
		               for="fixed-header-drawer-exp">
		          <i class="material-icons">search</i>
		        </label>
		        
		        <div class="mdl-textfield__expandable-holder">
		          <input class="mdl-textfield__input" type="text" name="sample"
		                 id="fixed-header-drawer-exp">
		        </div>
      </div>
    </div>
  </header>

  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title "><a href="#">ANS</a></span>
    <div class="mdl-card">
           
            <div class="mdl-card__media" >
              <img src="../images/userimage.jpg" width="150" height="130"  alt="" style="padding-left: 25px; padding-right: 2px;">
            </div>
             <div class="mdl-card__title">
             
             <?php
								require_once "../db/db_config.php";
								$db_link = Connect_DB();
								$data = "";
								$sql = "SELECT `username` FROM `users` WHERE `email` = '$email'";
								if($sql = mysqli_query($db_link,$sql))
									$data = mysqli_fetch_assoc($sql);
								mysqli_close($db_link);
							?>
							<h2 class="mdl-card__title-text myactextUserName"> <?php echo $data['username']; ?> </h2>
             
              <!--<h2 class="mdl-card__title-text myactextUserName">Shivajinagar Police</h2>-->
            </div>
            
    </div>
     <nav class="nav mdl-navigation myactext">
      <a class="mdl-navigation__link" href="./user.php"><i class="material-icons">home</i> Home</a>
      <a class="mdl-navigation__link" href="./myaccount.php"><i class="material-icons">account_box</i> My Account</a>
      <a class="mdl-navigation__link" href="./nearbyhospitals.php"> <i class="material-icons">local_hospital</i> Near by Hospitals</a>
      <a class="mdl-navigation__link" href="./callambulance.php"><i class="material-icons">airport_shuttle</i> Call Ambulance</a>
      <a class="mdl-navigation__link" href="./help.php"><i class="material-icons">help</i> Help</a>
      <a class="mdl-navigation__link" href="../logout.php"><i class="material-icons">exit_to_app</i> Logout</a>
    </nav>
  </div>