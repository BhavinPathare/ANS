<!DOCTYPE html>
<html>
<head>
  <title>My Account</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <style>
      #map {
        width: 100%;
        height: 260px;
        background-color: grey;
      }
      
    </style>
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->

<?php 
include("./drawer.php"); 
?>

<?php
require './google_search_accident.php';
?>
				

<table class="mdl-data-table mdl-js-data-table  mdl-shadow--6dp tablealign ">
     <thead>
            <tr>
              <th class="mdl-data-table__cell--non-numeric">Field</th>
              <th>Value</th>
            </tr>
    </thead>
  <tbody>
      <tr><td class="mdl-data-table__cell--non-numeric">Provide Help</td>
          <td>
          <div><!-- Accent-colored raised button -->
            <a href="./changepassword.php" style="color:white; text-decoration: none;">
                <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored ">
                    Call Ambulance</button></a>
              </div>
          </td>
      </tr>
     <tr>
          <td class="mdl-data-table__cell--non-numeric">Location</td>
          <td>Om Super,Modi Colony</td>
    </tr>
    <tr>
          <td class="mdl-data-table__cell--non-numeric">Name</td>
          <td>Mr.Aakash Sharma</td>
    </tr>
    <tr>
          <td class="mdl-data-table__cell--non-numeric">Distance</td>
          <td>1.52 Kms</td>
    </tr>
    <tr>
          <td class="mdl-data-table__cell--non-numeric">Vehicle</td>
          <td>Tata Nano MH-12-AS-5151</td>
    </tr>
    <tr>
          <td class="mdl-data-table__cell--non-numeric">Time</td>
          <td>14:51:55</td>
    </tr>
  </tbody>
</table>  
          </div>
        </div>
      </main>
</div>
</body>
</html>
