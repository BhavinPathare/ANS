<?php

$url="http://".$_SERVER['HTTP_HOST'];
session_start();

if(!isset($_SESSION['user']))
{
	session_destroy();
	header('Location:'.$url);
}

?>



<!DOCTYPE html>
<html>
<head>
  <title>My Account</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-pink.min.css">
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
  
<?php 
include("./drawer.php"); 
?>
  
  <main class="mdl-layout__content">
    <div class="page-content">
    <div class="mdl-grid-myac ">
        <div class="demo-container mdl-grid ">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
          <center><h3>README</h3></center>             
              <p>
                Commodo nisi non consectetur voluptate incididunt mollit duis dolore amet amet tempor exercitation. Qui amet aute ea aute id ad aliquip proident. Irure duis qui labore deserunt enim in quis nisi sint consequat aliqua. Ex proident labore et laborum tempor fugiat sint magna </p><p>veniam minim. Nulla dolor labore adipisicing in enim mollit laboris fugiat eu. Aliquip minim cillum ullamco voluptate non dolore non ex duis fugiat duis ad. Deserunt cillum ad et nisi amet non voluptate culpa qui do. Labore ullamco et minim proident est laborum mollit ad labore deserunt ut irure dolore. </p>Reprehenderit ad ad irure ut irure qui est eu velit eu excepteur adipisicing culpa. Laborum cupidatat ullamco eu duis anim reprehenderit proident aute ad consectetur eiusmod.
              </p>
          </div>
        </div>
      </main>
    
 	
	  </div>
	</div>
  </main>
</div>
</body>
</html>
