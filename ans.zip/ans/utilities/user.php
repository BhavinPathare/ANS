<!DOCTYPE html>
<html>
<head>
  <title>USER</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-pink.min.css">
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <style>
      #map {
        width: 100%;
        height: 560px;
        background-color: grey;
      }
    </style>

	</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
  
  <?php
	   require './drawer.php';
require './google_search.php';
?> 

  <main class="mdl-layout__content">
    <div class="page-content">
      <div class="mdl-grid">
      <div id="map">
      
     
      
      </div>
      
  </div>
  </main>
</div>
</body>
</html>
