<!DOCTYPE html>
<html>
<head>
  <title>User Guide</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
        <label class="mdl-button mdl-js-button mdl-button--icon"
               for="fixed-header-drawer-exp">
          <i class="material-icons">search</i>
        </label>
        <div class="mdl-textfield__expandable-holder">
          <input class="mdl-textfield__input" type="text" name="sample"
                 id="fixed-header-drawer-exp">
        </div>
      </div>
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title ">ANS</span>
    <nav class="nav mdl-navigation">
      <a class="mdl-navigation__link" href="">home</a>
      <a class="mdl-navigation__link" href="">help</a>
      <a class="mdl-navigation__link" href="">contact</a>
      <a class="mdl-navigation__link" href="">about us</a>
      <a class="mdl-navigation__link" href="">home</a>
      <a class="mdl-navigation__link" href="">help</a>
      <a class="mdl-navigation__link" href="">contact</a>
      <a class="mdl-navigation__link" href="">about us</a>
    </nav>
  </div>
  <main class="mdl-layout__content">
    <div class="page-content">
      <div class="mdl-grid">
      <div id="map"></div>
      
<!-- Simple Text -->

    <form action="#" align="center">
      <div class="mdl-textfield mdl-js-text">
        <label class="mdl-text" for="sample1">User Guide</label><br><br>
    	     <label class="mdl-text" for="sample1">Actions to be taken after receiving accident notification
                    1.Track Location
                    2.Inform to nearest hospital using nearby health services tab
                    3.Inform to head person
          </label>
	   </div>
   </form>
 </main>
</div>
</body>
</html>
