<?php
session_start();
$msg = "";
$url="http://".$_SERVER['HTTP_HOST'];
if(!isset($_SESSION['user']))
{
	session_destroy();
	header('Location:'.$url);
}
$email=$_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Account</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->

<?php
include("./drawer.php");
?>

  <!-- myac card -->
   <main class="mdl-layout__content">
    <div class="page-content">
    	<div class="mdl-grid-myac ">
        <div class="demo-container mdl-grid ">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
	          <center><h2>Account Details</h2></center>
	  				<div class="mdl-textfield mdl-js-text myactext">
							<?php
								require_once "../db/db_config.php";
								$db_link = Connect_DB();
								$data = "";
								$sql = "SELECT `username`, `city`, `pincode`, `state`, `address`, `mobile_no` FROM `users` WHERE `email` = '$email'";
								if($sql = mysqli_query($db_link,$sql))
									$data = mysqli_fetch_assoc($sql);
								mysqli_close($db_link);
							?>
							<font style="color:#651FFF">Station Name:</font> <?php echo $data['username']; ?>
							<br><font style="color:#651FFF">Station Address:</font> <?php echo $data['address']; ?>
							<br><font style="color:#651FFF">Division:</font> <?php echo $data['city']; ?>
							<br><font style="color:#651FFF">State:</font> <?php echo $data['state']; ?>
							<br><font style="color:#651FFF">Pincode:</font> <?php echo $data['pincode']; ?>
							<br><font style="color:#651FFF">Contact Number:</font> <?php echo $data['mobile_no']; ?>
						</div>
						<br><br>
						<div>
							<!-- Accent-colored raised button -->
			    		<a href="changepassword.php" style="color:white; text-decoration: none;"><input type="submit" name="submit" value="Change Password" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			        </a>
			  		</div>
          </div>
        </div>
			</div>
		</div>
	</main>
</body>
</html>
