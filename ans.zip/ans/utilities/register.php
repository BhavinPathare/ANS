<?php 

// if submitted check response
if (isset($_POST['submit'])) {
 
if (1==1) {
    //Everything Well And Good
	
    require '../db/db_func.php';
   
    $address=sanitize($_POST['Address']);
    $city=sanitize($_POST['city']);
    $state=sanitize($_POST['state']);
    $pincode=sanitize($_POST['pincode']);
    $mob=sanitize($_POST['mobile']);
    $email=sanitize($_POST['Email']);
    $user=sanitize($_POST['User']);
    $pass=sanitize($_POST['Password']);
    $userlat=sanitize($_POST['userlat']);
    $userlong=sanitize($_POST['userlong']);	
    
   if(!empty($address)&&!empty($city)&&!empty($state)&&!empty($pincode)&&!empty($mob)&&!empty($pass)&&!empty($email)&&!empty($user)&&!empty($userlat)&&!empty($userlong))
    {	
	$st=0;
        if($st==0)
        {
            $status=insertValues($email,$address,$city,$state,$pincode,$user,$pass,$mob,$userlat,$userlong);
            //Values Inserted Successfully
            echo "<script>sessionStorage.clear();</script>";
            echo "<script>window.location='./registrationfinal.php'</script>";
           
        }
    }
}
else
{
    echo "<script>document.getElementById('error').innerHTML='<b>Invalid Input</b>, Please Try Again';</script>";
}

}


?>

<!doctype html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Registration</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="images/android-desktop.png">

    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <link rel="shortcut icon" href="images/favicon.png">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
    <link rel="stylesheet" href="../style/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    #navlinkfont{
      color: black;
      font-size: 16px;
      
    }

    </style>
   
	
  </head>
  
  <body>
    
	<div class="demo-layout mdl-layout mdl-layout--fixed-header mdl-js-layout mdl-color--grey-100">
      <header class="demo-header mdl-layout__header mdl-layout__header--scroll mdl-color--grey-100 mdl-color-text--grey-800">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title"><a href="../index.php">Accident Notification System<a/></span>
          <div class="mdl-layout-spacer"></div>
          <nav class="mdl-navigation mdl-layout--large-screen-only myactext">
        <a class="mdl-navigation__link" id="navlinkfont" href="../index.php">Home</a>
        <a class="mdl-navigation__link" id="navlinkfont" href="./help.php">Help</a>
        <a class="mdl-navigation__link" id="navlinkfont" href="./contactus.php">Contact Us</a>
        <a class="mdl-navigation__link" id="navlinkfont"  href="./aboutus.php">About Us</a>
      </nav>
          <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
            <label class="mdl-button mdl-js-button mdl-button--icon" for="search">
              <i class="material-icons">search</i>
            </label>
            <div class="mdl-textfield__expandable-holder">
              <input class="mdl-textfield__input" type="text" id="search">
            </div>
          </div>
        </div>
      </header>
      <div class="demo-ribbon"></div>
      <main class="demo-main mdl-layout__content">
        <div class="demo-container mdl-grid">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
          <center><h3>Registration form</h3></center>
            
			<form action="#" name="f1" id="f1" method="POST" align="center">
			
            <h6 style="color:#3F51B5;">Note: Email id will be your username</h6><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                
                   <input class="mdl-textfield__input" type="text" id="User" name="User" pattern="-?[a-zA-Z]{5,}?" required>
                    <label class="mdl-textfield__label" for="sample3">Enter Police Station Name</label>
					<span class="mdl-textfield__error">Username must be alphabetical and minimum 5 characters without space</span>
					
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="Password" name="Password" pattern="-?(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*+=~`<>,._-]).{8,}?" required id="Password">
                    <label class="mdl-textfield__label" for="sample3">Enter Password</label>
					<span class="mdl-textfield__error">Password must be minimum 8 characters, should have atleast 1 Uppercase alphabet, 1 Lowercase alphabet, 1 Numerical and 1 Special character</span>
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="Password" required name="cPassword" id="cPassword" pattern="-?(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*+=~`<>,._-]).{8,}?">
                    <label class="mdl-textfield__label" for="sample3">Confirm Password</label>
					<span class="mdl-textfield__error">password not match</span>
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="text" name="Email" id="Email" required pattern="-?[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}?">
                    <label class="mdl-textfield__label" for="sample3">Enter Email ID</label>
					<span class="mdl-textfield__error">Please enter valid email address</span>
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield">
                                  
								  <!-- input pattern attribute -->
			<input class="mdl-textfield__input" type="text" pattern="-?[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]&?" id="mobile" name="mobile" required/>
					<!-- mdl-textfield__label -->
			<label class="mdl-textfield__label" for="demo-input">Phone Number</label>
			<!-- class "mdl-textfield__error" -->
			<span class="mdl-textfield__error">Phone Number must be numerical</span>
		</div><br><br>
  
                <div class="mdl-textfield mdl-js-textfield">
                  <textarea class="mdl-textfield__input" name="Address" id="Address" rows="3" class="form-control" required></textarea>
                  <label class="mdl-textfield__label" for="sample5">Enter Address</label>
				  <span class="mdl-textfield__error">Please enter valid address</span>
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                  <input class="mdl-textfield__input" type="text" name="pincode" id="pincode" maxlength="6" pattern="-?[0-9]{6}?"required>
                    <label class="mdl-textfield__label" for="sample4">Enter Pincode</label>
                        <span class="mdl-textfield__error">Pincode must be 6 digit</span>
						
                </div><br><br>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="text" id="city" name="city" pattern="-?[a-zA-Z]{3,}?" required>
                    <label class="mdl-textfield__label" for="sample3">City</label>
					<span class="mdl-textfield__error">Please enter valid city name</span>
					
                </div><br><br>

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="text" id="state" name="state" pattern="-?[a-zA-Z]{3,}?" required>
                    <label class="mdl-textfield__label" for="sample3">State</label>
					<span class="mdl-textfield__error">Please enter valid state name</span>
                </div><br><br>
		<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="text" id="userlat" name="userlat" required>
                    <label class="mdl-textfield__label" for="sample3">Enter Latitude</label>
					<span class="mdl-textfield__error">Please enter valid Latitude</span>
                </div><br><br>
		<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                   <input class="mdl-textfield__input" type="text" id="userlong" name="userlong" required>
                    <label class="mdl-textfield__label" for="sample3">Enter Longitude</label>
					<span class="mdl-textfield__error">Please enter valid Longitude</span>
                </div><br><br><br>
		<p><h5>To know your Latitude and Longitude please <a href="http://latlong.net/" target="_blank">click here!</a></h5></p>
                <br><br><br><br>
                <div class="myactext2">
                <!-- Accent-colored raised button -->
				  
				  <input type="submit" id="submit" name="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent" value="Register">
                  </div>
            </form><br>
            
          </div>
        </div>
        <footer class="demo-footer mdl-mini-footer">
          <div class="mdl-mini-footer--left-section">
            <ul class="mdl-mini-footer--link-list">
              <li><a href="#">Credits</a></li>
              <li><a href="#">Privacy and Terms</a></li>
              <li><a href="#">User Agreement</a></li>
            </ul>
          </div>
        </footer>
      </main>
    </div>
    
    <script src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  </body>
</html>
