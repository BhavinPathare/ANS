<!DOCTYPE html>
<html>
<head>
  <title>My Account</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  
</head>
<body>

<?php
include("./drawer.php"); 
?>

  <main class="mdl-layout__content">
    <div class="page-content">
    <div class="mdl-grid-myac">
      

        <div class="demo-container mdl-grid ">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
          <center><h2>Near by Hospitals</h2>            
  				
  			<div class="mdl-textfield mdl-js-text">
			<!-- Hospitals Table -->   
    		<table class="mdl-data-table mdl-js-data-table  mdl-shadow--4dp">
  			<thead>
				    <tr>
				      <th class="mdl-data-table__cell--non-numeric">Hospital Name</th>
							  <th>Address</th>
			
				    </tr>
  			</thead>
  			<tbody class="ntr">
												<tr class="nearbyhospitals_tablerow">
												  <td class="mdl-data-table__cell--non-numeric"> H Care </td>
												  <td> 25 KM </td>
												</tr>
												
												<tr>
												  <td class="mdl-data-table__cell--non-numeric"> Apollo </td>
												  <td> 50 KM </td>
												</tr>
												
												<tr>
												  <td class="mdl-data-table__cell--non-numeric"> XYZ Hospitals </td>
												  <td> 10 KM </td>
												</tr>
										</tbody>

			</table></center>   
			</div>
      
   
 		
	  </div>
	</div>
	<?php
	require './google_search.php';
?>
	
  </main>
</div>
</body>
</html>
