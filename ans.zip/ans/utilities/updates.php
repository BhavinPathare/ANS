<?php
session_start();
if(isset($_SESSION['lastId'])){
	require_once 'dbConnect.php';
	$id=$_SESSION['lastId'];
	$conn=connectDB();
}
else{
	die("Access Denied.");
}
?>
<!DOCTYPE html>

<html>
	<head>
		<title>Accident Details</title>
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/>
		<link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-pink.min.css"/>
		<script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
		<link rel="stylesheet" href="../style/styles.css"/>
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet"/>
		<!-- Css code -->
		<style>
			#map {
				height: 100%;
				width: 100%;
				}
			</style>
	</head>
	<!-- Body starts here -->
	<body>
	<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
					mdl-layout--fixed-header">

		<header class="mdl-layout__header">

			<div class="mdl-layout__header-row">

				<div class="mdl-layout-spacer"></div>
				<div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
								mdl-textfield--floating-label mdl-textfield--align-right">
								<label class="mdl-button mdl-js-button mdl-button--icon"
								for="fixed-header-drawer-exp">
          				<i class="material-icons"> search </i>
        				</label>
								<div class="mdl-textfield__expandable-holder">
									<input class="mdl-textfield__input" type="text" name="sample" id="fixed-header-drawer-exp"/>
								</div>
				</div>

			</div>

		</header>

		<div class="mdl-layout__drawer">
			<span class="mdl-layout-title ">ANS</span>
			<div class="mdl-card">
				<div class="mdl-card__media">
					<img src="../images/userimage.jpg" width="150" height="130"  alt="" style="padding-left: 25px; padding-right: 2px;">
				</div>
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text myactext"> Shivajinagar Police </h2>
				</div>
			</div>

			<!-- Left navigation bar starts here -->

			<nav class="nav mdl-navigation myactext">

				<a class="mdl-navigation__link" href="./user.php"> Home <i class="material-icons"> home </i></a>
				<a class="mdl-navigation__link" href="./myaccount.php"> My Account <i class="material-icons"> account_box </i></a>
				<a class="mdl-navigation__link" href="./nearbyhospitals.php"> Near by Hospitals <i class="material-icons"> local_hospital </i></a>
				<a class="mdl-navigation__link" href="./callambulance.php"> Call Ambulance <i class="material-icons"> airport_shuttle </i></a>
				<a class="mdl-navigation__link" href="./help.php"> Help <i class="material-icons"> help </i></a>
				<a class="mdl-navigation__link" href="../index.php"> Logout <i class="material-icons"> exit_to_app </i></a>

			</nav>

		</div>

			<!-- Navigation bar ends here -->

			<!-- Goggle maps starts here -->

   <main class="mdl-layout__content">

		<div class="page-content">

			<div class="mdl-grid-myac-custom">

				<div class="demo-container mdl-grid ">

					<div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>

					<div class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">

		 				<input id="pac-input" class="controls" type="text" placeholder="Search Box"/>
						<div id="map" ></div>

						<?php
						$query="SELECT `name`,`landmark`,`contactNo`,`lat`,`lng` FROM `location` WHERE `id`=$id";
						$query=mysqli_query($conn,$query);
						$row=mysqli_fetch_assoc($query);
						mysqli_close($conn);
						$pos="{lat: ".$row['lat'].", lng: ".$row['lng']."}";
						?>

			<script>

			var map;  //A Global Map Object
      function initAutocomplete() {
        var pos=<?php
          echo $pos;
          ?>;
          map = new google.maps.Map(document.getElementById('map'), {
          center: pos,
		      zoom: 16,
          mapTypeId: 'roadmap'
        });

        //Creating A Marker To Latest Position
        var marker = new google.maps.Marker({
          position: pos,
          map: map,
        });

        // Create the search box and link it to the UI element.
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function() {
          searchBox.setBounds(map.getBounds());
        });

        var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function() {
          var places = searchBox.getPlaces();

          if (places.length == 0) {
            return;
          }

          // Clear out the old markers.
          markers.forEach(function(marker) {
            marker.setMap(null);
          });
          markers = [];

          // For each place, get the icon, name and location.
          var bounds = new google.maps.LatLngBounds();
          places.forEach(function(place) {
            if (!place.geometry) {
              console.log("Returned place contains no geometry");
              return;
            }
            var icon = {
              url: place.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            // Create a marker for each place.
            markers.push(new google.maps.Marker({
              map: map,
              icon: icon,
              title: place.name,
              position: place.geometry.location
            }));

            if (place.geometry.viewport) {
              // Only geocodes have viewport.
              bounds.union(place.geometry.viewport);
            } else {
              bounds.extend(place.geometry.location);
            }
          });
          map.fitBounds(bounds);
        });

        var request = {
          location: pos,
          radius: 500,
          types: ['hospital', 'health'] // this is where you set the map to get the hospitals and health related places
        };

        infowindow = new google.maps.InfoWindow();
        var service = new google.maps.places.PlacesService(map);
        service.nearbySearch(request, callback);
      }


      function callback(results, status) {
        if (status == google.maps.places.PlacesServiceStatus.OK) {
          for (var i = 0; i < results.length; i++) {
            createMarker(results[i],'hospital');
          }
        }
      }

      function createMarker(place,type) {
        var placeLoc = place.geometry.location;
        var marker = new google.maps.Marker({
          map: map,
          icon: './images/icons/'+type+'.png',
          position: place.geometry.location
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.setContent(place.name);
          infowindow.open(map, this);
        });
      }
      //google.maps.event.addDomListener(window, 'load', initAutocomplete);
    </script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoSyUgdxu_kxQVl6hseszijLlWPqit6JM&libraries=places&callback=initAutocomplete" async defer></script>

		<!--  Accident details Table starts here -->

			<table class="mdl-data-table mdl-js-data-table  mdl-shadow--6dp tablealign ">
				<thead>
					<tr>
						<th class="mdl-data-table__cell--non-numeric">Field</th>
						<th>Value</th>
					</tr>
				</thead>

			<tbody>
					<tr>
						<td class="mdl-data-table__cell--non-numeric">Provide Help</td>
						<td>
							<div><button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
								<a href="callambulance.html"  style="text-decoration:none">Call Ambulance</a></button>
							</div>
						</td>
					</tr>


					<tr>
						<td class="mdl-data-table__cell--non-numeric">Landmark</td>
						<td>
							<?php if(isset($row['landmark']))
											echo $row['landmark'];
										else
											echo "Landmark Not Available";
							?>
						</td>
					</tr>

					<tr>
						<td class="mdl-data-table__cell--non-numeric">Name</td>
						<td>
						<?php if(isset($row['name']))
										echo $row['name'];
									else
										echo "Name Not Provided In DB";
						?>
						</td>
					</tr>

					<tr>
						<td class="mdl-data-table__cell--non-numeric">Vehicle</td>
						<td>
							<?php if(isset($row['carName']))
											echo $row['carName'];
										else
											echo "Vehicle Info Not Available";
							?>
						</td>
					</tr>

					<tr>
						<td class="mdl-data-table__cell--non-numeric">Time</td>
						<td>
						<?php if(isset($row['toa']))
										echo $row['toa'];
									else
										echo "Time Of Accident Not Provided In DB";
						?>
						</td>
					</tr>

			</tbody>

			</table>
			<!-- Table ends here -->
		  </div>

		</div>

	  </main>

	  </div>

</body>
							<!-- Body ends here -->
</html>
