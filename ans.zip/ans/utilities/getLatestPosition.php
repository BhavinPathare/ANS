<?php
require_once "../db/db_config.php";
function getValues(){
	$conn=Connect_DB();
	$query="SELECT lat,lng FROM `location` ORDER BY `id` LIMIT 1";
//select lat long from location where assignment=username;
	if($query=mysqli_query($conn,$query)){
		$row=mysqli_fetch_assoc($query);
		return "{lat: ".$row['lat'].", lng: ".$row['lng']."}";
	}
	return $val;
}

?>
