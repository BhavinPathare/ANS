<?php

$url="http://".$_SERVER['HTTP_HOST'];
session_start();

if(!isset($_SESSION['user']))
{
	session_destroy();
	header('Location:'.$url);
}

?>



<!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-deep_purple.min.css" />
  <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
  <link rel="stylesheet" href="../style/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
                <label class="mdl-button mdl-js-button mdl-button--icon"
                       for="fixed-header-drawer-exp">
                  <i class="material-icons">search</i>
                </label>
                <div class="mdl-textfield__expandable-holder">
                  <input class="mdl-textfield__input" type="text" name="sample"
                         id="fixed-header-drawer-exp">
                </div>
      </div>
    </div>
  </header>

  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title ">ANS</span>
    <div class="mdl-card">
           
            <div class="mdl-card__media" >
              <img src="./images/userimage.jpg" width="150" height="130"  alt="" style="padding-left: 25px; padding-right: 2px;">
            </div>
             <div class="mdl-card__title"></div>
            
    </div>
    <nav class="nav mdl-navigation myactext">
        <a class="mdl-navigation__link" href="../index.php">Home <i class="material-icons">home</i></a>
        <a class="mdl-navigation__link" href="./help.php">Help <i class="material-icons">help</i></a>
        </a>
    </nav>
  </div>
  
  <main class="mdl-layout__content">
    <div class="page-content">
    <div class="mdl-grid-myac ">
        <div class="demo-container mdl-grid ">
          <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone"></div>
          <div class="help-custom demo-content mdl-color--white mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">
          <center><h3>+02265561651</h3></center>             
              
          </div>
        </div>
      </main>
  </div>
	</div>
  </main>
</div>
</body>
</html>
