<?php
$n=$_GET["name"];
$l=$_GET["licence"];
$lat=$_GET["lat"];
$long=$_GET["long"];
$time=$_GET["time"];
$c=$_GET["car"];
echo "accident data uploaded successfully!";
echo "<br>";
echo $n." ".$l." ".$lat." ".$long." ".$time." ".$c;


    $db_host="ansdbserver.cxvctsaaynbc.ap-south-1.rds.amazonaws.com";
    $db_user="ajay443617";
    $db_password="ajaybhavinans";
    $db_name="ans";

$con=mysqli_connect($db_host,$db_user,$db_password,$db_name);
if(mysqli_connect_errno($con)){
	die("Failed to connect to mysql:".mysqli_connect_error());
}
$sql="insert into accident values("'.$n.'","'.$l.'","'.$lat.'","'.$long.'","'.$time.'","'.$c.'");";
$result=mysqli_query($con, $sql);
echo $result;
mysqli_close($con);


?>
